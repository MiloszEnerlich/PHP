<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Komis samochodowy</title>
    <link rel='stylesheet' type='text/css' media='screen' href='auto.css'>
</head>
<body>
    <div class='baner'>
        <h1>SAMOCHODY</h1>
    </div>

    <div class='lewy'>
        <h2>Wykaz samochodów</h2>
        <?php
        function skrypt1(){

            $host="localhost";
            $user="root";
            $pass="";
            $db="komis";

            $conn=mysqli_connect($host,$user,$pass,$db);

            $sql="SELECT id,marka,model FROM samochody";

            $wynik=mysqli_query($polaczenia,$sql);
            while($wiersz=mysqli_fetch_assoc($wynik))
            {
                echo '<li>'.$wiersz['id'].' '.$wiersz['marka'].' '.$wiersz['model'].'</li>';
            }
        }
        ?>
        select id,marka,model from samochody; 
        <h2>Zamówienia</h2>
        <?php


        ?>
        select id, klient from zamowienia;
    </div>
    
    <div class='prawy'>
        <h2>Pełne dane: Fiat</h2>
        <?php


        ?>
        select * from samochody where marka='fiat';
    </div>

    <div class='stopka'>
        <table>
        <tr>    
            <td> 
                <a href='kwerendy.txt'><u>Kwerendy</u></a>
            </td>
            <td> 
                Autor: Miłosz
            </td>
            <td> 
                <img src='auto.png'> 
            </td>
        </tr>        
        </table>
    </div>
</body>
</html>